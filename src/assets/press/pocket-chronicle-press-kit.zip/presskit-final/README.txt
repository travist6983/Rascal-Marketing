POCKET CHRONICLE — PRESS KIT
Assembled 7 September 2026


START HERE

  index.html   Open it in any browser. It has everything below with the
               screenshots laid out, the demo video playable in the page,
               quotes you can use and descriptions you can paste. It works
               offline — no internet needed once you have the folder.

If you would rather not open an HTML file, everything is in plain files here
and this README covers the facts.


WHAT POCKET CHRONICLE IS

Two prompts a day about your kid. One is always a question — "What word do
they mispronounce that you don't want to correct?" The other is a small
mission: a photo, a video, their voice, or something to do together.

Answering takes about fifteen seconds. Every answer is filed with the prompt
that caused it, the day it happened, and your child's exact age on that day,
on a timeline they eventually inherit.

It was built by one parent, for himself, because he forgets to take pictures
and cannot remember why he took the ones he has.


THE FACTS

  Name            Pocket Chronicle
                  (App Store listing: PocketChronicle.App)
                  (home screen: Chronicle)
  Platform        iPhone, iOS 18.6 or later
  Released        7 September 2026
  Price           Free to download.
                  First 14 days fully open, no card, nothing to cancel.
                  Then the daily question is free forever; anything that
                  needs storage (photographs, video, voice) is membership at
                  $5.99/month or $59.99/year, one per household.
  Category        Lifestyle, rated 4+
  Developer       Travis Terry, working alone. No company, no investors.
  App Store       https://apps.apple.com/us/app/pocketchronicle-app/id6800155810
  Website         https://pocketchronicle.app
  Press contact   hello@pocketchronicle.app
  Instagram       @pocketchronicle.app


WHAT'S IN THIS FOLDER

  index.html                  The press page. Start here.
  README.txt                  This file.
  fact-sheet.md               The same facts in Markdown.
  boilerplate.txt             Descriptions at four lengths, to paste.

  icon/                       App icon.
      pocket-chronicle-icon-1024.png          1024x1024, square, no alpha
                                              (the App Store master)
      pocket-chronicle-icon-1024-rounded.png  same, with iOS corners
      pocket-chronicle-icon-512.png           512x512
      icon-320.png                            small, for the page itself

  screenshots/full/           The six main screenshots.
                              1206x2622 PNG, straight off the device.
                              No frame, no shadow, no marketing overlay.
  screenshots/more/           Thirteen more: onboarding, the composer, the
                              capture sheet, settings, the export.
  screenshots/thumbs/         Small JPEGs the page uses. Not for print.

  video/pocket-chronicle-demo.mp4
                              29.8 seconds, 1080x1920, H.264, silent.
                              Real screen recording of the app.
  video/pocket-chronicle-demo-poster.jpg
                              A still, if you need a thumbnail.

  fonts/                      The two typefaces the page uses. Nothing you
                              need, unless you are rebuilding the page.


SIX DETAILS THAT ARE EASY TO GET SLIGHTLY WRONG

  1. Two prompts a day, not one. One is always a question; the second is a
     mission. The App Store subtitle says "one prompt a day", which is
     shorthand for the free daily question.

  2. The daily question is answered by typing. Voice recording answers a
     voice mission, or a freeform entry you start yourself.

  3. Transcription needs iOS 26. The app runs on iOS 18.6 and later; on an
     older iPhone the recording is saved and kept, and only the transcript
     is missing.

  4. It is private, not local-only. Entries sync to Pocket Chronicle's own
     server — that is what lets a second parent write into the same archive
     and a new phone pick it up. The voice-to-text runs on the device.
     Please don't call it "local-first".

  5. The voice recorder holds ten minutes. Not two.

  6. After the first 14 days, "free" means the daily question. Anything that
     needs storage is membership. Everything already in the archive stays
     readable, searchable and exportable forever, on any tier.


PRESS ACCESS

Download it from the App Store, then email the address you signed up with to
hello@pocketchronicle.app. A lifetime membership goes on the account the same
day — no trial clock, no card, nothing to cancel.

Interviews, extra screenshots, a different cut of the video, or a particular
screen captured on a device you name: ask, and it comes back quickly.


ABOUT THE ARCHIVE IN THESE IMAGES

Every screenshot and every second of the video is a real build of the app.
The child in them — Wren — is invented, and every entry was written for this
press kit. No real family's data appears anywhere.

Images and video in this folder may be reproduced in coverage of Pocket
Chronicle.
